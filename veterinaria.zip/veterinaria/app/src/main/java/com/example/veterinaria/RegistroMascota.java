package com.example.veterinaria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroMascota extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registo_mascota);  //

        Button btnLogin = findViewById(R.id.button);  // Asegúrate de que el ID del botón coincida con el de tu XML
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crear un Intent para navegar a FormularioActivity
                Intent intent = new Intent(RegistroMascota.this, menu.class);
                startActivity(intent);  // Iniciar la nueva actividad
            }
        });
    }
}
