package com.example.veterinaria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ConsultaHistoriaClinica extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consulta_historia_clinica);  //

        Button btnLogin8 = findViewById(R.id.button8);  // Asegúrate de que el ID del botón coincida con el de tu XML
        btnLogin8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crear un Intent para navegar a FormularioActivity
                Intent intent = new Intent(ConsultaHistoriaClinica.this, menu.class);
                startActivity(intent);  // Iniciar la nueva actividad
            }
        });

    }
}
